﻿using BenchmarkDotNet.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperChinaVuZ {
    /// <summary>
    /// Класс, созданный для измерения скорости выполнения программы
    /// </summary>
    [MemoryDiagnoser]
    [RankColumn]
    public class SpeedTest {
        /// <summary>
        /// Метод, выполняет проверку
        /// </summary>
        [Benchmark]
        public void Check()
        {
            List<Student> students = new List<Student>(250000);
            for (int i = 0; i < 100000; i++)
                students.Add(new Student());
            School school = new School(students);
            school.StartLesson(Position.Preschool,students);
            school.EndLesson();
            school.StartLesson(Position.Junior,students);
            school.EndLesson();
            school.StartLesson(Position.Senior,students);
            school.EndLesson();
        }

    }
}
