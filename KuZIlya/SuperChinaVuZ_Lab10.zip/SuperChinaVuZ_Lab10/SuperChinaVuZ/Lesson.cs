﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperChinaVuZ {
    /// <summary>
    /// Класс, описывает среднестатистический урок китайского школьника
    /// </summary>
    public class Lesson {
        public List<Student> Students { get; set; } = new();
        public List<Student> AllStudents { get; set; } = new(); //Костыль для вывода и распределения санкций
        public Lesson(Position position, params List<Student> students)
        {
            Students = students.OrderBy(student => student.position).ThenBy(student => student.countPhone).ToList();
            int indexBest = Students.FindIndex(student => student.position == position);
            int indexWorst = Students.FindLastIndex(student => student.position == position);
            Students = Students[indexBest..indexWorst];
            Students.Reverse();
            AllStudents = Students[..];
        }
        /// <summary>
        /// Список всех школьников на уроке
        /// </summary>
        /// <returns>Строку для вывода школьников</returns>
        public StringBuilder ShowStudentsOnLesson()
        {
            StringBuilder builder = new StringBuilder();
            foreach (var student in Students)
                builder.Append(student + "\n");
            return builder;
        }

    }
}
