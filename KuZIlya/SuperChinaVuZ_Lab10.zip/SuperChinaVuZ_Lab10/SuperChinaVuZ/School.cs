﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperChinaVuZ {
    /// <summary>
    /// Класс, описывает детскую тюрьму
    /// </summary>
    public class School {
        private int sanction = 10;
        private List<Student> students = new List<Student>();
        public Lesson lesson = null;
        private bool lessonIsEnded;
        public School(List<Student> students) => this.students = students;
        /// <summary>
        /// Начинает урок
        /// </summary>
        /// <param name="position">Для какой категории школьников проводится урок</param>
        /// <param name="students">Список студентов для отбора на урок</param>
        public void StartLesson(Position position, params List<Student> students)
        {
            if (lesson == null || lessonIsEnded)
            {
                lesson = new Lesson(position, students);
                lessonIsEnded = false;
            }
            else
                throw new ArgumentException("Урок идёт! Кабинет для производства занят");
        }
        /// <summary>
        /// Завершает начатый урок, раздаёт детям санкции
        /// </summary>
        public void EndLesson()
        {
            sanction = lesson.Students.Count / 4;
            while (sanction > 0)
            {
                var studentsOnLesson = FindMinMaxEmployee();
                Reward(studentsOnLesson);
            }
            Position typeOfLesson = lesson.Students[0].position;
            students = students.OrderBy(student => student.position).ThenBy(student => student.countPhone).ToList();
            int indexFirst = students.FindIndex(student => student.position == typeOfLesson);
            int indexLast = students.FindLastIndex(student => student.position == typeOfLesson);
            List<Student> students1 = students[(indexLast + 1)..];
            students = students[..indexFirst];
            students.AddRange(lesson.Students);
            students.AddRange(students1);
            students.Sort();
            lessonIsEnded = true;
        }
        /// <summary>
        /// Находит лучшего и худшего студентов
        /// </summary>
        /// <returns>Кортеж вида (Лучший студент, Худший студент)</returns>
        /// <exception cref="ArgumentException">Если урок не начался</exception>
        public (Student coolStudent, Student badStudent) FindMinMaxEmployee()
        {
            if (lesson == null)
                throw new ArgumentException("Урок не начался!");
            var a = (lesson.AllStudents.First(), lesson.AllStudents.Last());
            return (lesson.AllStudents.First(), lesson.AllStudents.Last());
        }
        /// <summary>
        /// Отбирает еду у плохого студента, часть отдаёт хорошему, часть отдаёт партии
        /// </summary>
        /// <param name="studentsOnLesson">Кортеж вида (Лучший студент, Худший студент)</param>
        public void Reward((Student coolStudent, Student badStudent) studentsOnLesson)
        {
            Student coolStudent = lesson.Students.Find(student => student == studentsOnLesson.coolStudent);
            GiveReward(ref coolStudent);
            int indexOfCoolStudent = lesson.Students.FindIndex(student => student == coolStudent);
            lesson.Students[indexOfCoolStudent] = coolStudent;
            Student badStudent = lesson.Students.Find(student => student == studentsOnLesson.badStudent);
            DemandReward(ref badStudent);
            int indexOfBadStudent = lesson.Students.FindIndex(student => student == badStudent);
            lesson.Students[indexOfBadStudent] = badStudent;
            --sanction;
            lesson.AllStudents = lesson.AllStudents[1..^1];
        }
        private void GiveReward(ref Student coolStudent) => coolStudent.countLunch += (sanction/100 + 3);
        private void DemandReward(ref Student badStudent) => badStudent.countLunch -= sanction;
        /// <summary>
        /// Список всех школьников в школе
        /// </summary>
        /// <returns>Строку для вывода школьников</returns>
        public StringBuilder ShowStudents()
        {
            students.Sort();
            StringBuilder builder = new StringBuilder();
            foreach (var student in students)
                builder.Append(student + "\n");
            return builder;
        }

    }
}
