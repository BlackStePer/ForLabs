﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperChinaVuZ {
    public enum Position {
        Preschool,
        Junior,
        Senior
    }
    /// <summary>
    /// Класс, описывает среднестатистического китайского школьника
    /// </summary>
    public struct Student : IComparable<Student> {
        private static int id = 0;
        private static Random random = new Random();
        public Position position;
        public Student()
        {
            number = id;
            ++id;
            position = (Position)random.Next(0, 3);
        }
        public int number, countPhone = random.Next(53), countLunch = random.Next(2,4);
        /// <summary>
        /// Сравнивает работоспособность двух студентов
        /// </summary>
        /// <param name="student">Один из студентов</param>
        /// <returns>Число, информирующее о том, лучше студент или нет (см. int.CompareTo())</returns>
        public int CompareTo(Student student)
        {
            if (student.countPhone == countPhone)
                return student.position.CompareTo(position);
            return student.countPhone.CompareTo(countPhone);
        }
        public static bool operator ==(Student a, Student b) => a.number == b.number;
        public static bool operator !=(Student a, Student b) => a.number != b.number;
        //public static bool operator >(Student studentA, Student studentB) => studentA.countPhone > studentB.countPhone;
        //public static bool operator <(Student studentA, Student studentB) => studentA.countPhone < studentB.countPhone;
        public override string ToString() => $"Студент-{position} {number} произвёл {countPhone}, заслужил {countLunch} приёмов пищи";
    }
}
