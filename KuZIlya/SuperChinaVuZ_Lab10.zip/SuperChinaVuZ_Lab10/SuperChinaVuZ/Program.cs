﻿


//#define SpeedTest
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

namespace SuperChinaVuZ {

    class Program {
        public static void Main(string[] args)
        {
#if SpeedTest
            BenchmarkRunner.Run<SpeedTest>(); // Надо скачать + программу на релиз поставить
#else
            try
            {
                List<Student> students = new List<Student>(10000);
                for (int i = 0; i < 15000; i++)
                    students.Add(new Student());
                School school = new School(students);
                //Console.WriteLine(school.ShowStudents());
                school.StartLesson(Position.Senior, students);
                Console.WriteLine(school.lesson.ShowStudentsOnLesson()); //Урок идёт
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                school.EndLesson(); //Время санкций
                Console.WriteLine(school.lesson.ShowStudentsOnLesson());
                school.StartLesson(Position.Junior, students);
                school.EndLesson(); //Время санкций
                Console.WriteLine(school.lesson.ShowStudentsOnLesson());
                //Console.WriteLine(school.ShowStudents());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
#endif
        }
    }
}







